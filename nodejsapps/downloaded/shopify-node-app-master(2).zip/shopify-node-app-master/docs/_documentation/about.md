---
title:  "About"
handle: "about"
category: "about"
---

Dummy Public App for Shopify built with Node Includes Embedded App SDK [Elkfox](https://www.elkfox.com).

### Requirements

  - node.js >= 6.11.0
  - mongodb >= 3.2.9
  - npm >= 5.0.0
