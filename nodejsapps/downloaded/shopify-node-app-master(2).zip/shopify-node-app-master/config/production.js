module.exports = {
  APP_URI: '',
};
