module.exports = {
  APP_URI: 'https://e1e16fdc.ngrok.io',
};
