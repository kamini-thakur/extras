
<div class="configurator-mobile" style="display:none;">
	Liquid error: This liquid context does not allow includes.
</div>
<div class="configurator-desktop" style="display:none;">
	Liquid error: This liquid context does not allow includes.
</div>

<!-- Bootstrap -->
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<script type="text/javascript" src="https://static.sketchfab.com/api/sketchfab-viewer-1.0.1.js"></script>      
<script>
              // --------------------- CONFIGURATOR JS CODE -----------------------------------
              
                var iframe = document.getElementById( 'api-frame' );
                var version = '1.0.0';
                var urlid = '78cb139c1cbe4d6f8b31b5720f4e4f36';
                var client = null;
              	var materialHash = {};
                var geometries  = [];

                function loadmodel(){
                    
                    document.addEventListener('load', () => console.log('viewerready'))
                    var client = new Sketchfab( version, iframe );
                    client.init( urlid, {
                        success: function onSuccess( api ){
                            console.log( 'Success' );
                            api.load();
                            api.start();

                            api.addEventListener( 'viewerready', function() {
                                console.log( 'Viewer is ready');

                                api.getNodeMap(function (err, nodes) {
                                  if (!err) {
                                      nrGeometries = Object.keys(nodes).length;
                                      var index;
                                      for (var key in Object.keys(nodes)) {
                                          index = Object.keys(nodes)[key];
                                          if (nodes[index].type == "Geometry") {
                                              geometryName = nodes[index].name.split("_")[1];
                                              geometries[geometryName] = {id: nodes[index].instanceID};
                                          }
                                      }
                                     for (var key in geometries) {
                                          api.hide(geometries[key].id);
                                      }

                                      for (var key in geometries) {
                                          if ((key == "sbase") || (key == "spattern")) {
                                              api.show(geometries[key].id);
                                          }
                                      }
                                  }
                              });
                              
                                    api.getMaterialList(function (err, materials) {                                   
                                    for (var i = 0; i < materials.length; i++) {
                                        materialHash[materials[i].name] = materials[i];
                                    }
                                });
                              
//                               $('#AddToCart').click(function(e){  
//                                 api.getScreenShot(
//                                     'image/png',
//                                     function ( err, result ) {
//                                       console.log('getscreenshot');
//                                         console.log( result );
//                                       var encoded_image =  result;
//                                     }
//                                 );
//                               });

                                $('#pattern :button').on('click', function (event) {
                                    event.preventDefault();                                   
                                    currentFabricId = this.id;
                                  	var pattern_name = $(this).attr('data-title');
                                  	$('#patternButton').attr('src',currentFabricId);
                                  	$('.changePattern').text(pattern_name);
                                  	$('#getPattern').attr('data-pattern-name',pattern_name);
                                  	$('.showPatternName').css('display','block');
                                  	console.log('pattern file: ', currentFabricId + ".jpg");
                                    changeTex(currentFabricId + ".jpg", 'pattern');
                                    changeTex(currentFabricId + ".jpg", 'spattern');
                                });

                                $('#solid :button').on('click', function (event) {
                                    event.preventDefault();                                   
                                    currentFabricId = this.id; 
                                  	var solid_name = $(this).attr('data-title');
                                  	$('#solidButton').attr('src',currentFabricId);
                                  	$('.changeSolid').text(solid_name);
                                  	$('#getSolid').attr('data-solid-name',solid_name);
                                  	$('.showTrimName').css('display','block');
                                    console.log('solid color file: ', currentFabricId + ".jpg");
                                    changeTex(currentFabricId + ".jpg", 'base');
                                    changeTex(currentFabricId + ".jpg", 'sbase');
                                });
                              
                              
                                $('#cat :button').on('click', function (event) {
                                    event.preventDefault();
                                  
                                  	$('#AvailableRooms').addClass('in');
                                  	$('.rooms').css('display','block');
                                  
                                    var currentCat = this.id;
                                  	var currentCatPrice = $(this).attr('data-price');                                  	
									$('.CatRadio').removeClass('selectedRadio');
									$(this).closest(".Cat-buttons").find(".CatRadio").addClass('selectedRadio').trigger('click');
      
                                  	var selectedVariantID = $(this).attr('data-category-id');                    
                                  	$('#getCategory').attr('data-variant-selected',selectedVariantID);                          
                                    switch(currentCat) {
                                        case 'small':
                                            for (var key in geometries) {
                                                api.hide(geometries[key].id);
                                            }
                                            for (var key in geometries) {
                                                if ((key == "sbase") || (key == "spattern")) {
                                                    api.show(geometries[key].id);
                                                }
                                            }
                                            break;
                                        case 'big':
                                            for (var key in geometries) {
                                                api.hide(geometries[key].id);
                                            }
                                            for (var key in geometries) {
                                                if ((key == "base") || (key == "pattern") || (key == "edge")) {
                                                    api.show(geometries[key].id);
                                                }
                                            }
                                            break;
                                        case 'set':
                                            for (var key in geometries) {
                                                api.show(geometries[key].id);
                                            }
                                            break;
                                    }
                                });
                              
                                function changeTex(file1, part) {
                                api.addTexture(
                                    file1,
                                    function (err, textureUid1) {
                                        materialToUpdate1 = materialHash[part];
                                        materialToUpdate1.channels.DiffuseColor.texture.uid = textureUid1;
                                        api.setMaterial(materialToUpdate1, function () {
                                            console.log("Material updated");
                                        });
                                    });
                            };

                            } );
                        },
                        error: function onError(callback){
                            console.log(this.error);
                        },
                            annotations_visible: 0,
                            camera: 0,
                            autostart: 1,
                            preload: 1,
                            transparent: 0,
                            scrollwheel: 1,
                            ui_stop: 0,
                            ui_hint: 0
                    } );
                };
          
              loadmodel();
              
              // --------------------- END CONFIGURATOR JS CODE -----------------------------------
</script>


<style>
    /*3d viewer style */
        .hidelogoup{
            position: absolute;
            width: 100%;
            height: 52px;
            background: #ffffff;
            left: 0;
            top: 0;
            z-index:999;
            display: block;
            color: #fff;
        }
        .hidelogodown{
            position: absolute;
            width: 100%;
            height: 41px;
            background: #ffffff;
            left: 0;
            bottom: -1px;
            z-index:999;
            display: block;
            color: #fff;
        }
        #api-frame {
        height: 55vh;
        }
      
   		#3dframe{
     		width: 100px !important;
    		height: 100px !important;
            
        }
</style>

<script>
  	var width=$(window).width();
    if(width<=767)
    {
      $('.configurator-mobile').css('display','block');
      $('.configurator-desktop').remove();
      
      $('.product-price-desktop').css('display','none');
      $('.product-price-mobile').css('display','block');
    }
    else
    {
      $('.configurator-desktop').css('display','block');
      $('.configurator-mobile').remove();
    }
  
    $('input[type=radio][name=selectRoom]').change(function() {
        var room_image = $(this).val();
        var room_name = $(this).attr('data-room-Name');
        var show = $(this).attr('data-show');
        $('[id^=room]').hide();
        $('.patterns-wrapper').css('display','block');
        $('#'+show).css('display','block');
      	
      	if(width>767)
    	{
        	$('.changeRoom').text(room_name);
        }
        else
        {
          	$('.modal').removeClass('in');
          	$('.modal').css('display','none');
        }
//      	$('#patternButton').attr('src', room_image);
        $('#Button_room').attr('src', room_image);
      
      	$('#pattern').addClass('in');
      	$('#solid').addClass('in');

        $('.solidColor-wrapper').css('display','block');
    });
  
//   $('#quantity').change(function(){
//   		var quantity = $(this).val();
//     	var currentPrice = $('.money').attr('data-price');
//   });
  
//   function quantityChanging()
//   {
//     alert('functioncalled');
//     var quantity = $(this).val();
//     alert(quantity);
//   }
  
	 /* Add to cart code goes here */
  $(document).ready(function(){
  
    $('#AddToCart').click(function(e){  
      var variantID = $('#getCategory').attr('data-variant-selected');
      
      if(variantID == '')
      {
        variantID = "";
      }
      var quantity  = $('#quantity').val();
      var patternSelected = $('#getPattern').attr('data-pattern-name');
      var patternImg = $('#patternButton').attr('src');
      var solidSelected = $('#getSolid').attr('data-solid-name');
      
      var data={quantity: quantity,id: variantID,
                properties: {
                  'Pattern': patternSelected,
                  'Trim': solidSelected,
//                   'Pattern image': patternImg,
                }
               };
      $.ajax({
        url: '/cart/add.js',
        dataType: 'json',
        type: 'post',
        data: data,
        success: function(itemData) {
			window.location.href = "/cart";
            return ;
        }, 
        error: function(XMLHttpRequest) {
          var response = eval('(' + XMLHttpRequest.responseText + ')');
          response = response.description;
          console.log(response);

        }
      });
    });

  });

</script>


============ configurator-for-mobile ===============
  <div class="selected-items">
  <span class="showthis showPatternName" style="display:none;"><b>Selected Pattern: </b><span class="changePattern"></span></span>
  <span class="showthis showTrimName" style="display:none;"><b>Selected Trim: </b><span class="changeSolid"></span></span>
</div>
<!-- For mobile starts -->
<div id="welcomePop-up" class="popup_configurator for-mobile">
  
	 <!-------------Rooms starts here--------------->
      <div class="rooms">
        
       		
       		
       	
       		
       		
       	
       		
       		
       	
       		
       		
       	
       		
       		
       	
       		
       		
       	
        <button type="button" class="btn btn-block btn-default btn-xl selectButtons" data-toggle="modal" data-target="#AvailableRooms"><img id = "Button_room" src="" width="44" /><span class="changeRoom">Select Theme</span></button>
        <div id="AvailableRooms" class="modal fade" role="dialog">
          <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-body">
          
                            
               
          
                            
               
          
                            
               
          
                            
               
          
                            
               
          
                            
               
          
            </div>
            </div>
          </div>
        </div>
  	  </div>
     <!-------------Rooms ends here--------------->

  	<div class="pattern-solid-wrapper">
     <!-------------Patterns starts here--------------->
     <div class="patterns-wrapper">
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
        <button type="button" id="getPattern" data-pattern-name="" class="btn btn-block btn-default btn-xl selectButtons" data-toggle="modal" data-target="#pattern"><img id = "patternButton" src="" width="44" /><span class="">Select Pattern</span></button>
        <div id="pattern" class="modal">
          <div class="modal-dialog">
             <div class="modal-content">
             <div class="modal-body">
             
               
               
             
               
               
             
               
               
             
               
               
             
               
               
             
               
               
             
          </div>
         </div>
          </div></div></div>
         <!-------------Patterns ends here--------------->
         <!-------------Solid color starts here--------------->
         <div class="solidColor-wrapper patterns">
           	
              
              
       		
              
              
       		
              
              
       		
              
              
       		
              
              
       		
              
              
       		
             <button id="getSolid" data-solid-name="" type="button" class="btn btn-block btn-default btn-xl selectButtons" data-toggle="modal" data-target="#solid"><img id = "solidButton" src="" width="44" /><span class="">Select Trim</span></button>
             <div id="solid" class="patterns modal">
               <div class="modal-dialog">
                <div class="modal-content">
                 <div class="modal-body"> 
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
                  </div></div></div>
             </div>
         </div>
         <!-------------Solid color ends here--------------->
  	</div>
  <div class="price-cushionType-wrapper">
   			<div style="display:none;" class="product-price product-price-mobile" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
                  <span class="price" itemprop="price">
                    <span class="money" data-price=""></span>
                    
                      <span class="product-price-compare ">
                        <span class="original money">
                          
                        </span>
                        <span class="saving">
                          
                        </span>
                      </span>
                    
                  	</span>
                	</div>
  	     <!-------------Categories starts here--------------->
     <div class="categories">      
   
     <button style="display:none;" id="getCategory" type="button" class="btn btn-block btn-default btn-xl selectButtons" data-variants-name="" data-variant-selected="" data-toggle="collapse" data-target="#cat"> Select Cushion Type</button>
     <div id="cat" class="">  
       
     </div>
     </div>  
  </div>
<!--   	<div style="display:none;" id="generic_image"></div> -->
     <!-------------Categories ends here--------------->
</div>

<style>
   /* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content/Box */
.modal-content {
    background-color: #fefefe;
    margin: 15% auto; /* 15% from the top and centered */
    padding: 20px;
    border: 1px solid #888;
    width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button */
.close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
    cursor: pointer;
} 
</style>

=============== configurator-for-desktop========
  <!-- For desktop starts here -->
<div id="welcomePop-up" class="popup_configurator for-desktop" >
  
     <!-------------Categories starts here--------------->
  
     <div class="categories">      
     <button style="display:none;" id="getCategory" type="button" class="btn btn-block btn-default btn-xl selectButtons" data-variants-name="" data-variant-selected="" data-toggle="collapse" data-target="#cat"> Select Cushion Type</button>
     <div id="cat" class="">  
       
     </div>
     </div>  
<!--   	<div style="display:none;" id="generic_image"></div> -->
     <!-------------Categories ends here--------------->

	 <!-------------Rooms starts here--------------->
     <div class="rooms" style="display:none;">
       	
       		
       		
       	
       		
       		
       	
       		
       		
       	
       		
       		
       	
       		
       		
       	
       		
       		
       	
        <button type="button" class="btn btn-block btn-default btn-xl selectButtons" data-toggle="collapse" data-target="#AvailableRooms"><img id = "Button_room" src="" width="44" /><span class="changeRoom">Select Theme</span></button>
        <div id="AvailableRooms" class="collapse" role="dialog">  
          
               
               
          
               
               
          
               
               
          
               
               
          
               
               
          
               
               
          
        </div>
  	 </div>
     <!-------------Rooms ends here--------------->

  	<div class="pattern-solid-wrapper">
     <!-------------Patterns starts here--------------->
     <div class="patterns-wrapper" style="display:none;">
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
       		
       		
       
        <button type="button" id="getPattern" data-pattern-name="" class="btn btn-block btn-default btn-xl selectButtons" data-toggle="collapse" data-target="#pattern"><img id = "patternButton" src="" width="44" /><span class="changePattern">Select Pattern</span></button>
        <div id="pattern" class="collapse">
          
          	 
          	 
          
          	 
          	 
          
          	 
          	 
          
          	 
          	 
          
          	 
          	 
          
          	 
          	 
          
          </div>
         </div>
         <!-------------Patterns ends here--------------->
         <!-------------Solid color starts here--------------->
         <div class="solidColor-wrapper patterns" style="display:none;">
           	
       		
       		
       		
       		
       		
       		
       		
       		
       		
       		
       		
       		
       		
       		
       		
       		
       		
       		
             <button id="getSolid" data-solid-name="" type="button" class="btn btn-block btn-default btn-xl selectButtons" data-toggle="collapse" data-target="#solid"><img id = "solidButton" src="" width="44" /><span class="changeSolid">Select Trim</span></button>
             <div id="solid" class="patterns collapse">
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
             </div>
         </div>
         <!-------------Solid color ends here--------------->
  	</div>
</div>
