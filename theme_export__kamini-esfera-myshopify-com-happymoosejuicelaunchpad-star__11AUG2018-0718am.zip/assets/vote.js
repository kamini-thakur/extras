/*
$(document).ready(function(){
    $(document).on('click', '.vote', function(event){
            //event.preventDefault();
      
              var prodId =$(this).attr('data-prodId');
      		  var prodHandle =$(this).attr('data-prodHandle');
       		 var custId =$(this).attr('data-custId');
      		  //alert(prodHandle);
             
      		  alert(custId);
     		  localStorage.setItem('prevProd',prodHandle);
    		
              if(custId == "")
              {
                window.location.href = "/account/login";	
                //alert('data');
                return false;
              }

      
      		  //alert(prod_id);
         //     var value_id="#val"+btnid;

      
//       	 		$.ajax({
//                 type:"POST",
                
//                 url:"",
//                 data: {'value': 'added', 'prodId': prodId}, 
//                 success: function (data) {
                  
//                  alert(data);
//                  //$('#id').html('data');
//                 } 

//               });
      
        });
  
  
   $(document).on('click', '#log_in', function(event){
   
       var stored=localStorage.getItem('prevProd');
       var reference=document.referrer;
       alert(reference);
        if(reference == "https://kamini-esfera.myshopify.com/collections/all" || reference == "https://kamini-esfera.myshopify.com/products/"+stored )
        {
           alert('logged-in');
           alert(stored);
           $('#logged').attr('value','/products/'+stored);
//         window.location.href = "https://kamini-esfera.myshopify.com/products/"+stored ;
    
    	}
    });
  
  
   });
 */ 


/*=======================Voter app======================*/
/*
 var voterApp = {
    state : "{{ shop.metafields.unvote.unvoteToggle }}"
     
 };
  $(document).ready(function(){
    //alert(voterApp.state);
    //localStorage.setItem('prevProd','');
       var l=getUrl(); 
         if(l=='login')
         {
           if(!getReferrer())
           {
            localStorage.setItem('prevProd',''); 
           }
           
         }
    	
    
      // alert("value of l is : "+l);
       var r=getReferrer();
       //alert("value of r is : "+r);
           
    var p=localStorage.getItem('prevProd');
    //console.log(p);
    if(l==='account' && (p!='' && p!= null) )
    {
    	location.href='/products/'+p;
        localStorage.setItem('prevProd',''); 
    }
  
    $(document).on('click', '.vote', function(event)
   {
      var that=$(this);
      var isl=isLoggedIn(that);
     
      var locationPath = window.location.pathname;
      var prodId =$(this).attr('data-product-id');
      var prodHandle =$(this).attr('data-product-handle');
      var custId =$(this).attr('data-customer-id');
      localStorage.setItem('prevProd',prodHandle);
      if(!isl)
      {
         
         location.href='/account/login';
      }
      else
      {
          p=localStorage.getItem('prevProd');
          
          var r = document.referrer;
           var h=location.href;
          if(h.indexOf('products')!=-1){
          
             localStorage.setItem('prevProd',''); 
            that.html('<img src="https://en.savefrom.net/img/busy.gif" />');
            
          addVote(that,'add');
   
        }
          else
          {
           location.href='/products/'+p;
             localStorage.setItem('prevProd',''); 
          }
      }


      if(custId == "" && r)
      {
       // window.location.href = "/account/login";	
        return false;
      }
    });
  $(document).on('click', '.unvote', function(event)
   {
   
     var prodHandle =$(this).attr('data-product-handle');
      var custId =$(this).attr('data-customer-id');
      localStorage.setItem('prevProd',prodHandle);
    
      var r = document.referrer;

//         if(r.indexOf('products')!=-1){
//             var p=localStorage.getItem('prevProd');
//           location.href='/products/'+p;
//         }
      	var that=$(this);
    
      	var h=location.href;
    	var pre=localStorage.getItem('prevProd');

        if(h.indexOf('products')!=-1){
          	 localStorage.setItem('prevProd',''); 
          	 that.html('<img src="https://en.savefrom.net/img/busy.gif" />');
      		 addVote(that,'sub');
        }
        else
        {
			location.href = '/products/'+pre;
            localStorage.setItem('prevProd',''); 
        }
    
  });
  
   jQuery(document).on('click', '#log_in', function(event){
   
       var stored=localStorage.getItem('prevProd');
       var reference=document.referrer;
        
    });
  function getReferrer()
    {
      
        var r = document.referrer;
        var ref= r.split('/')[3];
        //alert(ref);
      	if(ref == '')
        {
          return true;
        }
      
        if(r.indexOf('collections')!=-1 || r.indexOf('products')!=-1){
        return true;
      	}
      
      return false;
    }
    
    function addVote(obj,m)
    {
      //alert('vote added');
      /////////////////////////////////////////////
			var pid= obj.attr('data-product-id');
            var cid= obj.attr('data-customer-id');
      
               if(m=='add')
                {
                 var i='add';
                }
               else
                {
               var i='sub';
                }
     
        var post_data={pid:pid,cid:cid,m:i}
            
            //var cartButton=$(this);
             $.ajax({
                      url: '/apps/client',
                      dataType: 'text',
                      type: 'post',
                      data: post_data,
                      success: function(d) {
                        // Re-enable add to cart button.
                      console.log(d);
                        var r=obj.parent().find('.vote-count');
                        var c=parseInt(r.text());
             
                        if(d=='voted')
                        {
						c=c+1;
                        r.text(c);
                        $('.vote-progress').val(c);
                          
                        obj.removeClass('vote');
                             if(voterApp.state=='toggleOn')
                             {
                        obj.html('UNSUPPORT');
						obj.addClass('unvote');
                             }
                        
                        else
                        {
                          obj.html('SUPPORTED');
						obj.addClass('vote-success');
                        }
                        
                        
                        }
                        else if(d=='unvote')
                        {
                          if(c > 0)
                          {                            
                         	c=c-1;
                          }
                        r.text(c);
                        $('.vote-progress').val(c);
                          
                        obj.removeClass('unvote');                          
                        obj.html('SUPPORT');
						obj.addClass('vote');
                        }
                        else if((d=='exists'))
                        {
                          alert('Looks like you have already voted');
                        }
                        
                        else
                        {
                          alert('Something went wrong');
                          
                        }
                     

                      }, 
                      error: function(XMLHttpRequest) {
                        var response = eval('(' + XMLHttpRequest.responseText + ')');

                        response = response.description;
                       alert(response);

                      }
                   });
      
    }
    
    function getUrl()
    {
      var h=location.href;
      var r=window.location.href.split('/'); console.log(r[3])
      if(h.indexOf('account?sid')!==-1 || r[3]=='account' )
      {
        if(h.indexOf('login')!==-1){
          return 'login';
        }
        if(h.indexOf('register')!==-1){
          return 'register';
        }
        return 'account';
        
      }
      
    }
    
    function isLoggedIn(obj)
    {
      var cid=obj.attr('data-customer-id');
      if(cid==='')
      {
       alert('You need to be logged in to VOTE. You will be redirected automatically to login page.'); 
       return false;
      }
      return true;
     
    }
  
   });

 */ 
